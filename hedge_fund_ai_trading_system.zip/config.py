# הכנס כאן את פרטי ה-API שלך מ-Alpaca
API_KEY = "PUT_YOUR_KEY"
SECRET_KEY = "PUT_YOUR_SECRET"
BASE_URL = "https://paper-api.alpaca.markets"
